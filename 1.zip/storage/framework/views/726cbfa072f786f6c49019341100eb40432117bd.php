<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Marca')); ?>

            <?php echo e(Form::text('Marca', $marca->Marca, ['class' => 'form-control' . ($errors->has('Marca') ? ' is-invalid' : ''), 'placeholder' => 'Marca'])); ?>

            <?php echo $errors->first('Marca', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/marca/form.blade.php ENDPATH**/ ?>