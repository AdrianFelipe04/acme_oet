<div class="box box-info padding-1">
    <div class="box-body">
        
        <!-- <div class="form-group">
            <?php echo e(Form::label('idTipopersona')); ?>

            <?php echo e(Form::text('idTipopersona', $persona->idTipopersona, ['class' => 'form-control' . ($errors->has('idTipopersona') ? ' is-invalid' : ''), 'placeholder' => 'Idtipopersona'])); ?>

            <?php echo $errors->first('idTipopersona', '<div class="invalid-feedback">:message</div>'); ?>

        </div> -->
        <div class="form-group">
            <?php echo e(Form::label('Tipo de Persona')); ?>

            <?php echo e(Form::select('idTipopersona', $tipopersona, $persona->idTipopersona, ['class' => 'form-control' . ($errors->has('idTipopersona') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de Persona'])); ?>

            <?php echo $errors->first('idTipopersona', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Cedula')); ?>

            <?php echo e(Form::text('Cedula', $persona->Cedula, ['class' => 'form-control' . ($errors->has('Cedula') ? ' is-invalid' : ''), 'placeholder' => 'Cedula'])); ?>

            <?php echo $errors->first('Cedula', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Primer nombre')); ?>

            <?php echo e(Form::text('Primernombre', $persona->Primernombre, ['class' => 'form-control' . ($errors->has('Primernombre') ? ' is-invalid' : ''), 'placeholder' => 'Primer nombre'])); ?>

            <?php echo $errors->first('Primernombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Segundo nombre')); ?>

            <?php echo e(Form::text('Segundonombre', $persona->Segundonombre, ['class' => 'form-control' . ($errors->has('Segundonombre') ? ' is-invalid' : ''), 'placeholder' => 'Segundo nombre'])); ?>

            <?php echo $errors->first('Segundonombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Apellidos')); ?>

            <?php echo e(Form::text('Apellidos', $persona->Apellidos, ['class' => 'form-control' . ($errors->has('Apellidos') ? ' is-invalid' : ''), 'placeholder' => 'Apellidos'])); ?>

            <?php echo $errors->first('Apellidos', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Direccion')); ?>

            <?php echo e(Form::text('Direccion', $persona->Direccion, ['class' => 'form-control' . ($errors->has('Direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('Direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Telefono')); ?>

            <?php echo e(Form::text('Telefono', $persona->Telefono, ['class' => 'form-control' . ($errors->has('Telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('Telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Ciudad')); ?>

            <?php echo e(Form::text('Ciudad', $persona->Ciudad, ['class' => 'form-control' . ($errors->has('Ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

            <?php echo $errors->first('Ciudad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/persona/form.blade.php ENDPATH**/ ?>