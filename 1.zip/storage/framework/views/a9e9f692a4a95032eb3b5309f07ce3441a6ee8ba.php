<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Tipo de vehiculo')); ?>

            <?php echo e(Form::text('Tipovehiculo', $tipovehiculo->Tipovehiculo, ['class' => 'form-control' . ($errors->has('Tipovehiculo') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de vehiculo'])); ?>

            <?php echo $errors->first('Tipovehiculo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/tipovehiculo/form.blade.php ENDPATH**/ ?>