<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Tipo de Persona')); ?>

            <?php echo e(Form::text('Tipopersona', $tipopersona->Tipopersona, ['class' => 'form-control' . ($errors->has('Tipopersona') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de Persona'])); ?>

            <?php echo $errors->first('Tipopersona', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <br>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/tipopersona/form.blade.php ENDPATH**/ ?>