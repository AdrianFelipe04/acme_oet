<?php $__env->startSection('template_title'); ?>
    <?php echo e($vehiculo->name ?? 'Ver Vehiculo'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Ver Vehiculo</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('vehiculos.index')); ?>"> Volver</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Placa:</strong>
                            <?php echo e($vehiculo->Placa); ?>

                        </div>
                        <div class="form-group">
                            <strong>Color:</strong>
                            <?php echo e($vehiculo->colore->Color); ?>

                        </div>
                        <div class="form-group">
                            <strong>Marca:</strong>
                            <?php echo e($vehiculo->marca->Marca); ?>

                        </div>
                        <div class="form-group">
                            <strong>Tipo de Vehiculo:</strong>
                            <?php echo e($vehiculo->tipovehiculo->Tipovehiculo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Conductor:</strong>
                            <?php echo e($vehiculo->personaP->Primernombre); ?> <?php echo e($vehiculo->personaP->Segundonombre); ?> <?php echo e($vehiculo->personaP->Apellidos); ?>

                        </div>
                        <div class="form-group">
                            <strong>Propietario:</strong>
                            <?php echo e($vehiculo->persona->Primernombre); ?> <?php echo e($vehiculo->persona->Segundonombre); ?> <?php echo e($vehiculo->persona->Apellidos); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/vehiculo/show.blade.php ENDPATH**/ ?>