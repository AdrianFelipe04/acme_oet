<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Placa')); ?>

            <?php echo e(Form::text('Placa', $vehiculo->Placa, ['class' => 'form-control' . ($errors->has('Placa') ? ' is-invalid' : ''), 'placeholder' => 'Placa'])); ?>

            <?php echo $errors->first('Placa', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Color')); ?>

            <?php echo e(Form::select('idColor', $color, $vehiculo->idColor, ['class' => 'form-control' . ($errors->has('idColor') ? ' is-invalid' : ''), 'placeholder' => 'Color'])); ?>

            <?php echo $errors->first('idColor', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Marca')); ?>

            <?php echo e(Form::select('idMarca', $marca, $vehiculo->idMarca, ['class' => 'form-control' . ($errors->has('idMarca') ? ' is-invalid' : ''), 'placeholder' => 'Marca'])); ?>

            <?php echo $errors->first('idMarca', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Tipo de Vehiculo')); ?>

            <?php echo e(Form::select('idTipovehiculo', $tipovehiculo, $vehiculo->idTipovehiculo, ['class' => 'form-control' . ($errors->has('idTipovehiculo') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de Vehiculo'])); ?>

            <?php echo $errors->first('idTipovehiculo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Conductor')); ?>

            <?php echo e(Form::select('idConductor', $persona, $vehiculo->idConductor, ['class' => 'form-control' . ($errors->has('idConductor') ? ' is-invalid' : ''), 'placeholder' => 'Conductor'])); ?>

            <?php echo $errors->first('idConductor', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Propietario')); ?>

            <?php echo e(Form::select('idPropietario',$persona, $vehiculo->idPropietario, ['class' => 'form-control' . ($errors->has('idPropietario') ? ' is-invalid' : ''), 'placeholder' => 'Propietario'])); ?>

            <?php echo $errors->first('idPropietario', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\acme_oet\resources\views/vehiculo/form.blade.php ENDPATH**/ ?>